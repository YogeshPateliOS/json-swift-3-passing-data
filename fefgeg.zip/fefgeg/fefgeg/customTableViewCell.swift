//
//  customTableViewCell.swift
//  fefgeg
//
//  Created by binal on 27/11/17.
//  Copyright © 2017 grras. All rights reserved.
//

import UIKit

class customTableViewCell: UITableViewCell {
    

 
    @IBOutlet weak var address: UITextField!
 
   @IBOutlet weak var email: UITextField!
 
 
    @IBOutlet weak var gender: UITextField!
    
  @IBOutlet weak var id: UITextField!

    
    @IBOutlet weak var name: UITextField!
    
    @IBOutlet weak var mobile: UITextField!
       
    @IBOutlet weak var home: UITextField!
   
    @IBOutlet weak var office: UITextField!
    
    
    
  
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
