

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate
    
{
    @IBOutlet weak var tbl1: UITableView!
    
    var names: [String] = []
    var contacts: [String] = []
    var arrAddress :[String] = []
    var arrGender:[String] = []
    var arrPhone :[String] = []
    var arrMobile:[String] = []
    var arrOffice : [String] = []
   
    
    var strUrl:NSString! = nil
    
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        callWebServcie()
    }
    
    

    func callWebServcie()
    {
        strUrl = "http://api.androidhive.info/contacts"
        //  let dbparams = "Name=harshil&Mobile=7698996060&DOB=26/09/2017&Address=abc1234"
        let defaultConfigObject = URLSessionConfiguration.default
        let defaultSession = URLSession(configuration: defaultConfigObject, delegate: nil, delegateQueue: OperationQueue.main)
        //Create an URLRequest
        let url = URL(string: strUrl as String)
        let urlRequest = NSMutableURLRequest(url: url!)
        //Create POST Params and add it to HTTPBody
        let params: String? = nil
        urlRequest.httpMethod = "GET"
        urlRequest.httpBody = params?.data(using: .utf8)
        let task = defaultSession.dataTask(with: urlRequest as URLRequest, completionHandler:
            {
                (
                data, response, error) in
                guard let _:Data = data, let _:URLResponse = response  , error == nil else
                {
                    print("error::\(String(describing: error?.localizedDescription))")
                    return
                }
                let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                print("resposneData:::\(dataString!)")
                do
                {
 //                    let allContactsData = try Data(contentsOf: strUrl!)
                    let allContacts = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.allowFragments) as! [String : AnyObject]
                    if let arrJSON = allContacts["contacts"]
                    {
                        for index in 0...arrJSON.count-1
                        {
                            let aObject = arrJSON[index] as! [String : AnyObject]
                            
                            self.names.append(aObject["name"] as! String)
                            self.contacts.append(aObject["email"] as! String)
                            self.arrAddress.append(aObject["address"] as! String)
                            self.arrGender.append(aObject["gender"] as! String)
                            let dictPhone = aObject["phone"] as! NSDictionary
                            print(dictPhone)
                            for _ in 0...dictPhone.count-1
                            {
                                self.arrPhone.append(dictPhone["home"] as! String)
                                self.arrMobile.append(dictPhone["mobile"] as! String)
                                self.arrOffice.append(dictPhone["office"] as! String)
                            }
                            
                        }
                        self.tbl1.reloadData()
                    }
                    print(self.names)
                    print(self.contacts)
                    print(self.arrAddress)
                    print(self.arrGender)
                    print(self.arrPhone)
                    print(self.arrMobile)
                    print(self.arrOffice)
                }
                catch let error as NSError
                {
                    print("Found an error - \(error)")
                }
          })
        task.resume()

    }
    func numberOfSections(in tableView: UITableView) -> Int {
       return 1
        
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return names.count
    }
 

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let  cell:customTableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell") as! customTableViewCell
        cell.address?.text = arrAddress[indexPath.row]
        cell.name?.text = names[indexPath.row]
        cell.gender?.text = arrGender[indexPath.row]
        cell.mobile?.text = arrMobile[indexPath.row]
        cell.home?.text = arrPhone[indexPath.row]
        cell.office?.text = arrOffice[indexPath.row]
        
       return cell;
    
        
        

    }
        
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }



}
